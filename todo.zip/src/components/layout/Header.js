import './Header.css'

function Header(){
    return(<h1>ToDo List</h1>)
}

export default Header